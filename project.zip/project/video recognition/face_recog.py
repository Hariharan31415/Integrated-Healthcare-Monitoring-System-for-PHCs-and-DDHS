import face_recognition
import cv2
import numpy as np
import os
import threading
import time
import requests

# Set IP camera URLs
camera_urls = [
    "http://192.168.43.1:8080/video",
    "http://192.168.43.73:8080/video"
]

# Load Haarcascade for face detection
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Folder containing doctors' images
image_folder = os.path.join(os.path.dirname(__file__), "doctors")

# Lists to store encodings and names
known_encodings = []
known_names = []

# Load and encode doctors' images
for filename in os.listdir(image_folder):
    if filename.endswith(('.jpg', '.png')):
        image_path = os.path.join(image_folder, filename)
        image = face_recognition.load_image_file(image_path)
        encodings = face_recognition.face_encodings(image)

        if encodings:
            known_encodings.append(encodings[0])
            known_names.append(os.path.splitext(filename)[0])
        else:
            print(f"Warning: No face found in {filename}. Skipping...")

if not known_encodings:
    print("Error: No valid doctor images found.")
    exit()

# Initialize video capture for cameras
caps = [cv2.VideoCapture(url) for url in camera_urls]

# Check if cameras are opened
for i, cap in enumerate(caps):
    if not cap.isOpened():
        print(f"Error: Camera {i+1} could not be opened.")
        exit()

print("Starting Doctor Monitoring...")

frame_lock = threading.Lock()
latest_frames = [None] * len(caps)

# Capture frames using threads
def capture_frames(index):
    global latest_frames
    while True:
        cap = caps[index]
        ret, frame = cap.read()
        
        if not ret:
            print(f"Reconnecting Camera {index + 1}...")
            cap.release()
            time.sleep(2)
            caps[index] = cv2.VideoCapture(camera_urls[index])  # Reinitialize
            continue
        
        with frame_lock:
            latest_frames[index] = frame.copy()

# Start capturing threads
for i in range(len(caps)):
    threading.Thread(target=capture_frames, args=(i,), daemon=True).start()

# Send doctor data to the server
detected_doctors = set()

def send_doctor_to_server(doctor_name, camera_id):
    detection_time = time.strftime('%Y-%m-%d %H:%M:%S')
    data = {
        "doctor_name": doctor_name,
        "detected_at": detection_time,
        "camera_number": camera_id + 1
    }
    try:
        response = requests.post('http://localhost:5000/store-doctor', json=data)
        if response.status_code == 200:
            print(f"Doctor {doctor_name} detected on Camera {camera_id + 1} at {detection_time}")
        else:
            print(f"Failed to store doctor: {response.json().get('message', 'Unknown error')}")
    except Exception as e:
        print(f"Error sending data: {e}")


# Perform face recognition
def recognize_faces():
    while True:
        with frame_lock:
            frames = [frame.copy() if frame is not None else None for frame in latest_frames]

        for i, frame in enumerate(frames):
            if frame is None:
                continue  # Skip processing if no frame is available

            small_frame = cv2.resize(frame, (0, 0), fx=0.75, fy=0.75)
            rgb_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
            face_locations = face_recognition.face_locations(rgb_frame, model="hog")
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

            for face_encoding, face_location in zip(face_encodings, face_locations):
                matches = face_recognition.compare_faces(known_encodings, face_encoding)
                name = "Unknown"
                
                if True in matches:
                    face_distances = face_recognition.face_distance(known_encodings, face_encoding)
                    best_match_index = np.argmin(face_distances)

                    if matches[best_match_index]:
                        name = known_names[best_match_index]
                        send_doctor_to_server(name, i)

                # Draw rectangle and label
                top, right, bottom, left = [v * 4 // 3 for v in face_location]
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2, cv2.LINE_AA)

        time.sleep(0.1)  # Reduce CPU usage

threading.Thread(target=recognize_faces, daemon=True).start()

# Display camera feeds
def display_cameras():
    while True:
        with frame_lock:
            frames = [
                frame if frame is not None else np.zeros((480, 640, 3), dtype=np.uint8)
                for frame in latest_frames
            ]

        if all(f is None for f in frames):
            continue  # Skip rendering if no valid frames

        # Resize frames to ensure consistency
        frames = [cv2.resize(frame, (640, 480)) for frame in frames]
        cols = int(np.ceil(np.sqrt(len(frames))))
        rows = int(np.ceil(len(frames) / cols))

        while len(frames) < cols * rows:
            frames.append(np.zeros((480, 640, 3), dtype=np.uint8))

        frame_rows = [cv2.hconcat(frames[i * cols:(i + 1) * cols]) for i in range(rows)]
        grid_frame = cv2.vconcat(frame_rows)

        cv2.imshow("Doctor Monitoring - All Cameras", grid_frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

threading.Thread(target=display_cameras, daemon=True).start()

# Cleanup function
def cleanup():
    for cap in caps:
        cap.release()
    cv2.destroyAllWindows()

# Run the program
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("Stopping Monitoring...")
    cleanup()


