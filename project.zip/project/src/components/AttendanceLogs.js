import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './AttendanceLogs.css';
import { useNavigate } from 'react-router-dom';


function AttendanceLogs() {
  const [logs, setLogs] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:5000/ddhs/attendance-logs', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setLogs(response.data);
      } catch (err) {
        setError('Failed to load attendance logs');
      }
    };
    fetchLogs();
  }, []);
const navigate = useNavigate();

const handleAddDailyAttendance = async () => {
  try {
    await axios.post('http://localhost:5000/add-daily-attendance');
    alert('Daily attendance log added successfully!');
  } catch (err) {
    alert('Failed to add attendance log.');
  }
};


  return (
    <div className="attendance-log-page">
      <h2>Attendance Logs</h2>
      {error && <p className="error">{error}</p>}
      <table className="attendance-log-table">
  <thead>
    <tr>
      <th>Doctor Name</th>
      <th>Hospital Name</th>
      <th>Date</th>
      <th>Detected Time</th>
      <th>Camera Number</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
  {logs.map((log, index) => (
    <tr key={index}>
      <td>{log.doctorName}</td>
      <td>{log.hospitalName}</td>
      <td>{log.date}</td>
      <td>{log.detectedTime || '—'}</td>
      <td>{log.cameraNumber || '—'}</td>
      <td className={log.status === 'Present' ? 'status-present' : 'status-absent'}>
        {log.status}
      </td>
    </tr>
  ))}
</tbody>
</table>
<br></br>
<a
  href="http://localhost:5000/download-attendance"
  download
  target="_blank"
  rel="noopener noreferrer"
>
  <button style={{ padding: '10px 20px', margin: '20px', fontWeight: 'bold' }}>
    Download Attendance Excel
  </button>
</a>

<button
  onClick={handleAddDailyAttendance}
  style={{ padding: '10px 20px', margin: '20px', fontWeight: 'bold', backgroundColor: 'green', color: 'white' }}
>
  Add Today's Attendance Log
</button>

<button
  onClick={() => navigate('/all-daily-attendance')}
  style={{ padding: '10px 20px', margin: '20px', fontWeight: 'bold', backgroundColor: 'purple', color: 'white' }}
>
  View All Day-wise Attendance
</button>

    </div>
  );
}

export default AttendanceLogs;



// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import './AttendanceLogs.css';

// function AttendanceLogs() {
//   const [logs, setLogs] = useState([]);
//   const [error, setError] = useState('');
//   const [selectedDate, setSelectedDate] = useState('');
//   const [doctorList, setDoctorList] = useState([]);
//   const [selectedDoctor, setSelectedDoctor] = useState('');
//   const [submitMessage, setSubmitMessage] = useState('');

//   useEffect(() => {
//     fetchLogs(); // default = today's logs
//     fetchDoctors();
//   }, []);

//   const fetchLogs = async (date = '') => {
//     try {
//       const token = localStorage.getItem('token');
//       const url = date
//         ? `http://localhost:5000/ddhs/attendance-logs?date=${date}`
//         : `http://localhost:5000/ddhs/attendance-logs`;
//       const response = await axios.get(url, {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setLogs(response.data);
//       setError('');
//     } catch (err) {
//       setError('Failed to load attendance logs');
//     }
//   };

//   const fetchDoctors = async () => {
//     try {
//       const response = await axios.get('http://localhost:5000/doctors');
//       setDoctorList(response.data);
//     } catch (err) {
//       console.error('Failed to fetch doctors');
//     }
//   };

//   const handleManualSubmit = async () => {
//     if (!selectedDoctor || !selectedDate) {
//       setSubmitMessage('Please select doctor and date');
//       return;
//     }

//     try {
//       await axios.post('http://localhost:5000/ddhs/add-attendance', {
//         doctorName: selectedDoctor,
//         date: selectedDate,
//       });
//       setSubmitMessage('Attendance added successfully');
//       fetchLogs(); // Refresh logs
//     } catch (err) {
//       setSubmitMessage('Error adding attendance');
//     }
//   };

//   const handleDateFilter = () => {
//     if (selectedDate) fetchLogs(selectedDate);
//   };

//   return (
//     <div className="attendance-log-page">
//       <h2>Attendance Logs</h2>

//       {error && <p className="error">{error}</p>}

//       <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
//         <div>
//           <label>Select Date:</label>
//           <input
//             type="date"
//             value={selectedDate}
//             onChange={(e) => setSelectedDate(e.target.value)}
//           />
//           <button onClick={handleDateFilter}>View Day-wise Attendance</button>
//         </div>

//         <div>
//           <label>Select Doctor:</label>
//           <select
//             value={selectedDoctor}
//             onChange={(e) => setSelectedDoctor(e.target.value)}
//           >
//             <option value="">-- Select --</option>
//             {doctorList.map((doc, i) => (
//               <option key={i} value={doc.name}>
//                 {doc.name}
//               </option>
//             ))}
//           </select>
//           <button onClick={handleManualSubmit}>Add Attendance</button>
//           <p>{submitMessage}</p>
//         </div>
//       </div>

//       <table className="attendance-log-table">
//         <thead>
//           <tr>
//             <th>Doctor Name</th>
//             <th>Hospital Name</th>
//             <th>Date</th>
//             <th>Detected Time</th>
//             <th>Camera Number</th>
//             <th>Status</th>
//           </tr>
//         </thead>
//         <tbody>
//           {logs.map((log, index) => (
//             <tr key={index}>
//               <td>{log.doctorName}</td>
//               <td>{log.hospitalName}</td>
//               <td>{log.date}</td>
//               <td>{log.detectedTime || '—'}</td>
//               <td>{log.cameraNumber || '—'}</td>
//               <td className={log.status === 'Present' ? 'status-present' : 'status-absent'}>
//                 {log.status}
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>

//       <br />
//       <a
//         href="http://localhost:5000/download-attendance"
//         download
//         target="_blank"
//         rel="noopener noreferrer"
//       >
//         <button style={{ padding: '10px 20px', margin: '20px', fontWeight: 'bold' }}>
//           Download Attendance Excel
//         </button>
//       </a>
//     </div>
//   );
// }

// export default AttendanceLogs;

