import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import './DetectedDoctors.css';

function DetectedDoctors() {
  const [doctors, setDoctors] = useState([]);
  const location = useLocation();
  const hospitalName = location.state?.hospitalName;

  useEffect(() => {
    const fetchDetectedDoctors = async () => {
      if (hospitalName) {
        try {
          const response = await axios.get(
            `http://localhost:5000/ddhs/detected-doctors?phc=${encodeURIComponent(hospitalName)}`
          );

          // 🌟 Filter out duplicate doctors by name
          const seenNames = new Set();
          const uniqueDoctors = [];

          response.data.forEach((doctor) => {
            if (!seenNames.has(doctor.name)) {
              seenNames.add(doctor.name);
              uniqueDoctors.push(doctor);
            }
          });

          setDoctors(uniqueDoctors);
        } catch (err) {
          console.error('Failed to fetch detected doctors', err);
        }
      }
    };

    fetchDetectedDoctors();
  }, [hospitalName]);

  return (
    <div className="detected-doctors-container">
      <h2 className="title">Available Doctors in {hospitalName}</h2>

      {doctors.length === 0 ? (
        <p className="no-doctors">No doctors detected today.</p>
      ) : (
        <div className="doctors-list">
          {doctors.map((doctor) => (
            <div key={doctor.doctor_id} className="doctor-card">
              <img
                src={`http://localhost:5000/uploads/doctors/${doctor.profile_image}`}
                alt={doctor.name}
                className="doctor-image"
              />
              <div className="doctor-info">
                <h3>{doctor.name}</h3>
                <p><strong>Specialization:</strong> {doctor.specialization}</p>
                <p><strong>Designation:</strong> {doctor.designation}</p>
                <p><strong>Hospital:</strong> {doctor.hospital_name}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default DetectedDoctors;
