import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Alerts.css';


function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const response = await axios.get('http://localhost:5000/recent-alerts');
        setAlerts(response.data);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load alerts');
      }
    };

    fetchAlerts();
  }, []);

  return (
    <div className="alerts-page">
      <h2>Recent Alerts</h2>
      {error && <p className="error">{error}</p>}
      <table className="alerts-table">
        <thead>
          <tr>
            <th>Doctor Name</th>
            <th>Contact Number</th>
            <th>Message</th>
            <th>Sent At</th>
          </tr>
        </thead>
        <tbody>
          {alerts.map((alert, index) => (
            <tr key={index}>
              <td>{alert.doctor_name}</td>
              <td>{alert.contact_number}</td>
              <td>{alert.message_body}</td>
              <td>{new Date(alert.sent_at).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Alerts;
