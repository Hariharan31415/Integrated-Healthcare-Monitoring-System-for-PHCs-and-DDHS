import React, { useEffect, useState } from 'react';
import axios from 'axios';

function AllDailyAttendance() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const fetchAllLogs = async () => {
      const response = await axios.get('http://localhost:5000/all-daily-attendance');
      setLogs(response.data);
    };
    fetchAllLogs();
  }, []);

  return (
    <div>
      <h2>All Day-wise Attendance Logs</h2>
      <table className="attendance-log-table">
        <thead>
          <tr>
            <th>Doctor Name</th>
            <th>Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log, idx) => (
            <tr key={idx}>
              <td>{log.doctor_name}</td>
              <td>{new Date(log.date).toISOString().split('T')[0]}</td>
              <td style={{ color: log.status === 'Present' ? 'green' : 'red' }}>{log.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AllDailyAttendance;
