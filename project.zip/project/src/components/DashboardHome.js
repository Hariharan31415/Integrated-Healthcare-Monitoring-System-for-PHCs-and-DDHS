import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './DashboardHome.css'; 

function DashboardHome() {
  const [stats, setStats] = useState({
    totalDoctors: 0,
    totalPHCs: 0,
    todayAttendance: 0,
    recentAlerts: []
  });

  const [phcAttendance, setPhcAttendance] = useState([]);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  useEffect(() => {
    const token = localStorage.getItem('token');

    const fetchStats = async () => {
      try {
        const response = await axios.get('http://localhost:5000/ddhs/overview-stats', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        setStats(response.data);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch dashboard data');
      }
    };

    const fetchPHCStats = async () => {
      try {
        const response = await axios.get('http://localhost:5000/ddhs/phc-wise-attendance', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        const uniquePhcs = [];
        const seen = new Set();

        response.data.forEach(phc => {
          if (!seen.has(phc.hospital_name)) {
            seen.add(phc.hospital_name);
            uniquePhcs.push(phc);
          }
        });

        setPhcAttendance(uniquePhcs);
      } catch (err) {
        console.error('Failed to fetch PHC attendance', err);
        setError('Failed to fetch PHC attendance data');
      }
    };

    fetchStats();
    fetchPHCStats();
  }, []);

  const handleViewDetectedDoctors = (hospitalName) => {
    navigate('/detected-doctors', { state: { hospitalName } });
  };

  return (
    <div className="dashboard-home">
      {/* Navigation Bar */}
      <div className="nav-bar">
        <button onClick={() => navigate('/ddhs-dashboard')}>🏠 Home</button>
        <button onClick={() => navigate('/doctor-list')}>👨‍⚕️ Doctor List</button>
        <button onClick={() => navigate('/attendance-logs')}>📋 Attendance Logs</button>
        <button onClick={() => navigate('/alerts')}>🚨 Alerts</button>
        <button onClick={handleLogout}>🚪 Logout</button>
      </div>

      <h2 className="dashboard-title">DDHS Dashboard Overview</h2>

      {error && <p className="error">{error}</p>}

      <div className="stats-container">
        <div className="stat-card">
          <h3>Total Doctors</h3>
          <p>{stats.totalDoctors}</p>
        </div>
        <div className="stat-card">
          <h3>Total PHCs</h3>
          <p>{stats.totalPHCs}</p>
        </div>
        <div className="stat-card">
          <h3>Today's Attendance</h3>
          <p>{stats.todayAttendance}</p>
        </div>
      </div>

      {/* PHC Attendance Section */}
      <div className="phc-section">
        <h3 id="phc">Primary Healthcare Centers</h3>
        <div className="phc-cards">
          {phcAttendance.map((phc, index) => (
            <div key={index} className="phc-card">
              <h4>{phc.hospital_name}</h4>
              <p><strong>Total Doctors:</strong> {phc.total_doctors}</p>
              <p><strong>Today's Attendance:</strong> {phc.today_attendance}</p>
              <button
                style={{ marginTop: '10px', cursor: 'pointer' }}
                onClick={() => handleViewDetectedDoctors(phc.hospital_name)}
              >
                View Doctors
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default DashboardHome;
