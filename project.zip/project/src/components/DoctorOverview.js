import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './DoctorOverview.css'; 

const DoctorOverview = () => {
  const [doctors, setDoctors] = useState([]);

  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        const response = await axios.get('http://localhost:5000/doctors');
        setDoctors(response.data);
      } catch (error) {
        console.error('Failed to fetch doctors:', error);
      }
    };

    fetchDoctors();
  }, []);

  return (
    <div className="doctor-overview">
      <h2>Doctors Overview</h2>
      <div className="doctor-list">
        {doctors.map((doctor) => (
          <div key={doctor.doctor_id} className="doctor-card">
            <img
              src={`http://localhost:5000/uploads/doctors/${doctor.profile_image}`}
              alt={doctor.name}
              className="profile-img"
            />
            <div className="doctor-details">
              <h3>{doctor.name}</h3>
              <p><strong>Specialization:</strong> {doctor.specialization}</p>
              <p><strong>Designation:</strong> {doctor.designation}</p>
              <p><strong>Hospital:</strong> {doctor.hospital_name}</p>
              <p><strong>Contact:</strong> {doctor.contact_number}</p>
              <p><strong>Email:</strong> {doctor.email}</p>
              <p><strong>Availability:</strong> {doctor.availability}</p>
              <p><strong>Last Seen:</strong> {doctor.last_seen ? new Date(doctor.last_seen).toLocaleString() : 'N/A'}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DoctorOverview;
