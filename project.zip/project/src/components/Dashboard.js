import React, { useState } from "react";
import axios from "axios";
import { FaUserMd, FaCamera } from "react-icons/fa";
import "./Dashboard.css";

function Dashboard() {
  const [showModal, setShowModal] = useState(false);
  const [doctorData, setDoctorData] = useState({
    doctor_id: "",
    name: "",
    specialization: "",
    designation: "",
    hospital_name: "",
    contact_number: "",
    email: "",
    profile_image: null,
    availability: "",
    last_seen: "",
  });

  const handleTriggerRecognition = async () => {
    try {
      const token = localStorage.getItem("token");
      await axios.post(
        "http://localhost:5000/trigger",
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert("Face recognition started!");
    } catch (error) {
      alert(
        "Failed to start face recognition: " +
          (error.response?.data?.message || error.message)
      );
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setDoctorData({ ...doctorData, [name]: value });
  };

  const handleFileChange = (e) => {
    setDoctorData({ ...doctorData, profile_image: e.target.files[0] });
  };

  const handleAddDoctor = async () => {
    try {
      const formData = new FormData();
      Object.keys(doctorData).forEach((key) => {
        formData.append(key, doctorData[key]);
      });

      await axios.post("http://localhost:5000/add-doctor", formData);
      alert("Doctor added successfully!");
      setShowModal(false);
    } catch (error) {
      alert(
        "Error adding doctor: " +
          (error.response?.data?.message || error.message)
      );
    }
  };

  return (
    <div className="dashboard-container">
      <h1 className="dashboard-title">Welcome to the Dashboard</h1>

      <div className="dashboard-buttons">
        <button className="face-recognition-btn" onClick={handleTriggerRecognition}>
          <FaCamera className="icon" /> Start Face Recognition
        </button>

        <button className="new-doctor-btn" onClick={() => setShowModal(true)}>
          <FaUserMd className="icon" /> New Doctor
        </button>
      </div>

      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Add New Doctor</h2>
            <input type="text" name="doctor_id" placeholder="Doctor ID" onChange={handleInputChange} />
            <input type="text" name="name" placeholder="Name" onChange={handleInputChange} />
            <input type="text" name="specialization" placeholder="Specialization" onChange={handleInputChange} />
            <input type="text" name="designation" placeholder="Designation" onChange={handleInputChange} />
            <input type="text" name="hospital_name" placeholder="Hospital Name" onChange={handleInputChange} />
            <input type="text" name="contact_number" placeholder="Contact Number" onChange={handleInputChange} />
            <input type="email" name="email" placeholder="Email" onChange={handleInputChange} />
            <input type="text" name="availability" placeholder="Availability" onChange={handleInputChange} />
            <input type="file" accept="image/*" onChange={handleFileChange} />
            <div className="modal-buttons">
              <button className="add-doctor-confirm" onClick={handleAddDoctor}>Add Doctor</button>
              <button className="close-modal" onClick={() => setShowModal(false)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;
