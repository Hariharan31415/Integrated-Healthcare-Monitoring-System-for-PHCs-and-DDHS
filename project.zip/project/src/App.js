import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import DashboardHome from './components/DashboardHome'; 
import DoctorOverview from './components/DoctorOverview'; 
import DetectedDoctors from './components/DetectedDoctors'; 
import AttendanceLogs from './components/AttendanceLogs'; 
import Alerts from './components/Alerts'; 
import AllDailyAttendance from './components/AllDailyAttendance'; // ✅ Add this line

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/ddhs-dashboard" element={<DashboardHome />} />
        <Route path="/doctor-list" element={<DoctorOverview />} />
        <Route path="/detected-doctors" element={<DetectedDoctors />} /> 
        <Route path="/attendance-logs" element={<AttendanceLogs />} />
        <Route path="/alerts" element={<Alerts />} />
        <Route path="/all-daily-attendance" element={<AllDailyAttendance />} /> {/* ✅ New Route */}
      </Routes>
    </Router>
  );
}

export default App;
