const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',      // Adjust username
  password: '2004@hari',      // Adjust password
  database: 'healthcare_monitoring',
  timezone: 'Z' 
});

db.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err.stack);
    return;
  }
  console.log('Connected to MySQL Database.');
});

module.exports = db;
