const express = require('express');
const bodyParser = require('body-parser');
const { spawn } = require('child_process');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const twilio = require('twilio');
const multer = require('multer');
const path = require('path');
const db = require('./db'); // or wherever you initialized mysql.createConnection()


const app = express();
const port = 5000;


// Secret for JWT
const secretKey = 'cebf976db9bbbe249b1faea2c75ff0e4797628c7264cab0e768be932108cb70557077eea1ed7b81baaa768591c260018592e8714f09bb96c0d03ef5d4f7a11eb';

// Twilio config
const accountSid = 'ACbd0427c9a9744f4b9e1b728d677a5b3f';
const authToken = 'd1a1f4ab5473334244dace31d0af7ea9';
const twilioPhoneNumber = '++13412016619';
const client = new twilio(accountSid, authToken);


// Middlewares 
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads'));
app.use('/uploads/doctors', express.static(path.join(__dirname, '..', 'video recognition', 'doctors')));
app.use('/uploads/doctors', express.static(path.join(__dirname, 'video recognition/doctors')));
// Multer setup
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

// Auth Middleware
const authenticateToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Unauthorized. Token missing.' });

  jwt.verify(token, secretKey, (err, user) => {
    if (err) return res.status(403).json({ message: 'Forbidden. Invalid token.' });
    req.user = user;
    next();
  });
};

// Role-Based Authorization
const authorizePHCSAdmin = (req, res, next) => {
  if (req.user.role !== 'PHCS Admin') {
    return res.status(403).json({ message: 'Unauthorized. Only PHCS Admins can trigger face recognition.' });
  }
  next();
};

// ================== ROUTES ================== //

// Login
app.post('/login', (req, res) => {
  const { username, password, role } = req.body;
  if (!username || !password || !role) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  db.query('SELECT * FROM users WHERE username = ? AND role = ?', [username, role], (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });

    if (results.length === 0 || results[0].password !== password) {
      return res.status(401).json({ message: 'Invalid username, password, or role' });
    }

    const user = { username: results[0].username, role: results[0].role };
    const token = jwt.sign(user, secretKey, { expiresIn: '1h' });

    res.json({ message: 'Login successful', token, role });
  });
});

// Register
app.post('/register', (req, res) => {
  const { username, password, role } = req.body;
  if (!username || !password || !role) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  db.query('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', [username, password, role], (err) => {
    if (err) return res.status(500).json({ message: 'Database error', error: err });
    res.json({ message: 'Registration successful' });
  });
});




// attendance log 
app.get('/ddhs/attendance-logs', (req, res) => {
  const query = `
    SELECT 
      d.name AS doctorName,
      d.hospital_name AS hospitalName,
      DATE_FORMAT(CURDATE(), '%Y/%m/%d') AS date,  -- format date as YYYY/MM/DD
      TIME(MIN(dd.detected_at)) AS detectedTime,
      MIN(dd.camera_number) AS cameraNumber,
      'Present' AS status
    FROM doctors d
    JOIN detected_doctors dd
      ON d.name = dd.doctor_name
    WHERE DATE(dd.detected_at) = CURDATE()
    GROUP BY d.name, d.hospital_name

    UNION

    SELECT 
      d.name AS doctorName,
      d.hospital_name AS hospitalName,
      DATE_FORMAT(CURDATE(), '%Y/%m/%d') AS date,  -- format date as YYYY/MM/DD
      '-' AS detectedTime,
      '-' AS cameraNumber,
      'Absent' AS status
    FROM doctors d
    WHERE d.name NOT IN (
      SELECT doctor_name FROM detected_doctors WHERE DATE(detected_at) = CURDATE()
    )
    ORDER BY doctorName;
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching attendance logs:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }

    res.json(results);
  });
});




app.get('/recent-alerts', (req, res) => {
  const query = `
    SELECT 
      doctor_name, 
      contact_number, 
      message_body, 
      DATE_FORMAT(sent_at, '%Y/%m/%d %H:%i:%s') AS sent_at
    FROM sent_alerts
    ORDER BY sent_at DESC
    LIMIT 10
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching recent alerts:', err);
      return res.status(500).json({ message: 'Failed to fetch recent alerts' });
    }

    res.json(results);
  });
});




// download the attendance log 
app.get('/download-attendance', (req, res) => {
  const query = `
    SELECT 
      d.name AS doctorName,
      d.hospital_name AS hospitalName,
      CURDATE() AS date,
      TIME(MIN(dd.detected_at)) AS detectedTime,
      MIN(dd.camera_number) AS cameraNumber,
      'Present' AS status
    FROM doctors d
    JOIN detected_doctors dd
      ON d.name = dd.doctor_name
    WHERE DATE(dd.detected_at) = CURDATE()
    GROUP BY d.name, d.hospital_name

    UNION

    SELECT 
      d.name AS doctorName,
      d.hospital_name AS hospitalName,
      CURDATE() AS date,
      '-' AS detectedTime,
      '-' AS cameraNumber,
      'Absent' AS status
    FROM doctors d
    WHERE d.name NOT IN (
      SELECT doctor_name FROM detected_doctors WHERE DATE(detected_at) = CURDATE()
    )
    ORDER BY doctorName;
  `;

  db.query(query, async (err, results) => {
    if (err) {
      console.error('Error generating Excel:', err);
      return res.status(500).send("Failed to generate Excel");
    }

    if (results.length === 0) {
      return res.status(204).send("No attendance data available");
    }

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Attendance Logs');

    worksheet.columns = [
      { header: 'Doctor Name', key: 'doctorName', width: 25 },
      { header: 'Hospital Name', key: 'hospitalName', width: 25 },
      { header: 'Date', key: 'date', width: 15 },
      { header: 'Detected Time', key: 'detectedTime', width: 15 },
      { header: 'Camera Number', key: 'cameraNumber', width: 15 },
      { header: 'Status', key: 'status', width: 10 }
    ];

    results.forEach(row => {
      worksheet.addRow(row);
    });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=attendance_logs.xlsx');

    await workbook.xlsx.write(res);
    res.end();
  });
});


const ExcelJS = require('exceljs');
const fs = require('fs');
const filePath = './doctor_attendance.xlsx';

app.get('/export-doctor-attendance', (req, res) => {
  db.query("SELECT * FROM detected_doctors", async (err, results) => {
    if (err) return res.status(500).json({ message: "Database error", error: err });

    // 🚫 If no records, return without writing to Excel
    if (results.length === 0) {
      return res.status(200).json({ message: "No doctor records found. Excel not written." });
    }

    try {
      const workbook = new ExcelJS.Workbook();
      let worksheet;

      if (fs.existsSync(filePath)) {
        await workbook.xlsx.readFile(filePath);
        worksheet = workbook.getWorksheet('Attendance');

        // In case worksheet is missing
        if (!worksheet) {
          worksheet = workbook.addWorksheet('Attendance');
          worksheet.columns = [
            { header: 'Doctor Name', key: 'doctor_name', width: 25 },
            { header: 'Detected At', key: 'detected_at', width: 30 },
            { header: 'Camera Number', key: 'camera_number', width: 15 }
          ];
        }
      } else {
        // Create new workbook and worksheet
        worksheet = workbook.addWorksheet('Attendance');
        worksheet.columns = [
          { header: 'Doctor Name', key: 'doctor_name', width: 25 },
          { header: 'Detected At', key: 'detected_at', width: 30 },
          { header: 'Camera Number', key: 'camera_number', width: 15 }
        ];
      }

      // Add rows from DB
      results.forEach(row => {
        worksheet.addRow({
          doctor_name: row.doctor_name,
          detected_at: row.detected_at,
          camera_number: row.camera_number
        });
      });

      // Write the Excel file
      await workbook.xlsx.writeFile(filePath);

      res.json({ message: "Doctor attendance exported to Excel successfully." });
    } catch (error) {
      console.error("Excel write error:", error);
      res.status(500).json({ message: "Excel write failed", error });
    }
  });
});



// Add Doctor with Profile Image
app.post('/add-doctor', upload.single('profile_image'), (req, res) => {
  const { doctor_id, name, specialization, designation, hospital_name, contact_number, email, availability } = req.body;
  const profileImage = req.file ? `/uploads/${req.file.filename}` : null;

  if (!doctor_id || !name || !specialization || !designation || !hospital_name || !contact_number || !email || !availability) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  db.query(`INSERT INTO doctors 
    (doctor_id, name, specialization, designation, hospital_name, contact_number, email, profile_image, availability) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
    [doctor_id, name, specialization, designation, hospital_name, contact_number, email, profileImage, availability], 
    (err) => {
      if (err) return res.status(500).json({ message: 'Database error', error: err });
      res.json({ message: 'Doctor added successfully!' });
    });
});

// store doctor 

app.post('/store-doctor', (req, res) => {
  const { doctor_name, detected_at, camera_number } = req.body;

  if (!doctor_name || !detected_at || !camera_number) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  db.query("INSERT INTO detected_doctors (doctor_name, detected_at, camera_number) VALUES (?, ?, ?)", 
    [doctor_name, detected_at, camera_number], (err) => {
    if (err) return res.status(500).json({ message: 'Database error', error: err });
    res.json({ message: `Doctor ${doctor_name} stored successfully.` });
  });
});

// ddhs overview attendance count 
app.get('/ddhs/overview-stats', async (req, res) => {
  try {
    const [doctors] = await db.promise().query(`
      SELECT COUNT(*) AS total_doctors FROM doctors
    `);

    const [phcs] = await db.promise().query(`
      SELECT COUNT(DISTINCT hospital_name) AS total_phcs FROM doctors
    `);

    // Step 1: Get detections for today ordered by doctor and detected time
    const [detections] = await db.promise().query(`
      SELECT doctor_name, camera_number, detected_at
      FROM detected_doctors
      WHERE DATE(detected_at) = CURDATE()
      ORDER BY doctor_name, detected_at
    `);

    const doctorCounters = {};

    // Step 2: Process each detection and simulate counter logic
    detections.forEach(({ doctor_name, camera_number }) => {
      if (!doctorCounters[doctor_name]) {
        doctorCounters[doctor_name] = 0;
      }

      if (camera_number === 1) {
        doctorCounters[doctor_name] += 1; // increment on camera 1
      } else if (camera_number === 2) {
        doctorCounters[doctor_name] = 0; // reset to 0 on camera 2
      }
    });

    // Step 3: Count doctors whose counter is still > 0 (present)
    const todayAttendance = Object.values(doctorCounters).filter(counter => counter > 0).length;

    res.json({
      totalDoctors: doctors[0].total_doctors,
      totalPHCs: phcs[0].total_phcs,
      todayAttendance: todayAttendance
    });

  } catch (err) {
    console.error("Error in /ddhs/overview-stats:", err);
    res.status(500).json({ message: "Server error", error: err });
  }
});


// phcs wise dashboard 
app.get('/ddhs/phc-wise-attendance', async (req, res) => {
  try {
    const [doctors] = await db.promise().query(`
      SELECT doctor_id, name AS doctor_name, hospital_name 
      FROM doctors
    `);

    const [detections] = await db.promise().query(`
      SELECT doctor_name, camera_number, detected_at 
      FROM detected_doctors 
      WHERE DATE(detected_at) = CURDATE()
      ORDER BY doctor_name, detected_at
    `);

    const doctorCounters = {};  // { doctor_name: { counter, hospital_name } }

    doctors.forEach(({ doctor_name, hospital_name }) => {
      doctorCounters[doctor_name] = { counter: 0, hospital_name };
    });

    detections.forEach(({ doctor_name, camera_number }) => {
      if (doctorCounters[doctor_name]) {
        if (camera_number === 1) {
          doctorCounters[doctor_name].counter += 1;
        } else if (camera_number === 2) {
          doctorCounters[doctor_name].counter = 0;
        }
      }
    });

    const phcMap = {};  // { hospital_name: { total_doctors, today_attendance } }

    doctors.forEach(({ doctor_name, hospital_name }) => {
      if (!phcMap[hospital_name]) {
        phcMap[hospital_name] = { total_doctors: 0, today_attendance: 0 };
      }

      phcMap[hospital_name].total_doctors += 1;

      const doctorData = doctorCounters[doctor_name];
      if (doctorData && doctorData.counter > 0) {
        phcMap[hospital_name].today_attendance += 1;
      }
    });

    const phcStats = Object.entries(phcMap).map(([hospital_name, stats]) => ({
      hospital_name,
      total_doctors: stats.total_doctors,
      today_attendance: stats.today_attendance
    }));

    res.json(phcStats);

  } catch (err) {
    console.error("Error in /ddhs/phc-wise-attendance:", err);
    res.status(500).json({ message: "Server error", error: err });
  }
});


// Detected doctors PHC-wise
app.get('/ddhs/detected-doctors', async (req, res) => {
  try {
    const { phc } = req.query;

    if (!phc) {
      return res.status(400).json({ message: "PHC is required." });
    }

    // Step 1: Get all doctors in the given PHC
    const [doctors] = await db.promise().query(`
      SELECT 
        d.doctor_id,
        d.name,
        d.specialization,
        d.designation,
        d.hospital_name,
        d.contact_number,
        d.email,
        d.profile_image
      FROM doctors d
      WHERE d.hospital_name = ?
    `, [phc]);

    // Step 2: Get today's detections for doctors in the PHC
    const [detections] = await db.promise().query(`
      SELECT 
        dd.doctor_name,
        dd.camera_number,
        dd.detected_at
      FROM detected_doctors dd
      JOIN doctors d ON dd.doctor_name = d.name
      WHERE d.hospital_name = ? AND DATE(dd.detected_at) = CURDATE()
      ORDER BY dd.doctor_name, dd.detected_at
    `, [phc]);

    // Step 3: Apply counter logic
    const doctorCounters = {};

    doctors.forEach(doc => {
      doctorCounters[doc.name] = 0;
    });

    detections.forEach(({ doctor_name, camera_number }) => {
      if (camera_number === 1) {
        doctorCounters[doctor_name] = (doctorCounters[doctor_name] || 0) + 1;
      } else if (camera_number === 2) {
        doctorCounters[doctor_name] = 0;
      }
    });

    // Step 4: Add availability info to each doctor
    const availableDoctors = doctors
      .filter(doc => doctorCounters[doc.name] > 0)
      .map(doc => ({
        ...doc,
        availability: 'Available'
      }));

    res.json(availableDoctors);

  } catch (err) {
    console.error("Error in /ddhs/detected-doctors:", err);
    res.status(500).json({ message: 'Server error' });
  }
});


// daily attendace adding 

app.post('/add-daily-attendance', (req, res) => {
  const query = `
    INSERT INTO daily_attendance_logs (doctor_name, status, date)
    SELECT doctorName, status, CURDATE() as date
    FROM (
      SELECT 
        d.name AS doctorName,
        IF(EXISTS (
          SELECT 1 FROM detected_doctors dd 
          WHERE dd.doctor_name = d.name 
          AND DATE(dd.detected_at) = CURDATE()
        ), 'Present', 'Absent') AS status
      FROM doctors d
    ) AS attendance;
  `;

  db.query(query, (err) => {
    if (err) {
      console.error('Error inserting attendance logs:', err);
      return res.status(500).json({ message: 'Error inserting daily attendance' });
    }
    res.json({ message: 'Daily attendance saved successfully' });
  });
});

// view all attendace
app.get('/all-daily-attendance', (req, res) => {
  const query = `
    SELECT 
      doctor_name,
      DATE(date) AS date, 
      status
    FROM daily_attendance_logs 
    ORDER BY date, doctor_name
  `;
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching all daily logs:', err);
      return res.status(500).json({ message: 'Error fetching daily attendance logs' });
    }
    res.json(results);
  });
});





// Trigger Face Recognition (For PHCS Admin)
app.post('/trigger', authenticateToken, authorizePHCSAdmin, (req, res) => {
  const pythonPath = "C:\\Program Files\\Python312\\python.exe";
  const scriptPath = 'D:\\healthcare-monitoring\\video recognition\\face_recog.py';

  const pythonProcess = spawn(pythonPath, [scriptPath]);

  pythonProcess.stdout.on('data', (data) => {
    console.log(`FaceRecog Output: ${data}`);
  });

  pythonProcess.stderr.on('data', (data) => {
    console.error(`FaceRecog Error: ${data}`);
  });

  pythonProcess.on('close', (code) => {
    res.json({ message: code === 0 ? 'Face recognition completed successfully!' : `Error: Exit code ${code}` });
  });
});

// ================== ALERT SYSTEM ================== //

// Send SMS Alert
function sendSmsAlert(doctorName, doctorPhoneNumber, detectedAt) {
  // Ensure phone number is in E.164 format for India
  if (!doctorPhoneNumber.startsWith('+')) {
    doctorPhoneNumber = '+91' + doctorPhoneNumber;
  }

   
  const message = `⚠️ Dear ${doctorName}, your attendance has not been recorded at the entry point within the expected time . So kindly ensure your presence.`;

  client.messages
    .create({
      body: message,
      from: twilioPhoneNumber,
      to: doctorPhoneNumber,
    })
    .then((messageResponse) => {
      console.log(`✅ Alert sent to ${doctorName}. SID: ${messageResponse.sid}`);

      // Insert alert log into database
      const insertQuery = `
        INSERT INTO sent_alerts (doctor_name, contact_number, detected_at, message_body, twilio_sid)
        VALUES (?, ?, ?, ?, ?)
      `;

      db.query(
        insertQuery,
        [doctorName, doctorPhoneNumber, detectedAt, message, messageResponse.sid],
        (err) => {
          if (err) {
            console.error(`❌ Error inserting alert log: ${err.message}`);
          }
        }
      );
    })
    .catch((error) => {
      console.error(`❌ Failed to send SMS to Dr. ${doctorName} (${doctorPhoneNumber}): ${error.message}`);
    });
}



// Periodic Alert Checker
function checkDoctorAlerts() {
  console.log("🔍 Checking for missing doctors in Camera 1...");

  const query = `
    SELECT d1.doctor_name, d1.detected_at AS last_seen_camera2, doc.contact_number
    FROM detected_doctors d1
    JOIN doctors doc ON d1.doctor_name = doc.name
    LEFT JOIN detected_doctors d2
      ON d1.doctor_name = d2.doctor_name
      AND d2.camera_number = 1
      AND d2.detected_at > d1.detected_at
    WHERE d1.camera_number = 2
      AND d2.doctor_name IS NULL
      AND TIMESTAMPDIFF(MINUTE, d1.detected_at, NOW()) >= 2
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error(`❌ Error checking alerts: ${err.message}`);
      return;
    }

    results.forEach(row => {
      sendSmsAlert(row.doctor_name, row.contact_number, row.last_seen_camera2);
    });    
  });
}

//get doctor info from db 

app.get('/doctors', (req, res) => {
  db.query('SELECT * FROM doctors', (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Database error', error: err });
    }
    res.json(results);
  });
});


// Run check every 5 minutes
setInterval(checkDoctorAlerts, 5 * 60 * 1000);

// ================== SERVER START ================== //
app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
